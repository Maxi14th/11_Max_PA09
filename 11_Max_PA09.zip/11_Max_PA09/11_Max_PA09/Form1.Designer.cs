﻿namespace _11_Max_PA09
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnconvert = new System.Windows.Forms.Button();
            this.rdbjapaneseyen = new System.Windows.Forms.RadioButton();
            this.rdbusdollar = new System.Windows.Forms.RadioButton();
            this.txtamount = new System.Windows.Forms.TextBox();
            this.txtconvertedamount = new System.Windows.Forms.TextBox();
            this.lblselectcurrency = new System.Windows.Forms.Label();
            this.lblamount = new System.Windows.Forms.Label();
            this.lblvalue = new System.Windows.Forms.Label();
            this.btnclear = new System.Windows.Forms.Button();
            this.rdb_MYR = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btnconvert
            // 
            this.btnconvert.Location = new System.Drawing.Point(1156, 383);
            this.btnconvert.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnconvert.Name = "btnconvert";
            this.btnconvert.Size = new System.Drawing.Size(150, 44);
            this.btnconvert.TabIndex = 0;
            this.btnconvert.Text = "Convert";
            this.btnconvert.UseVisualStyleBackColor = true;
            this.btnconvert.Click += new System.EventHandler(this.btnconvert_Click);
            // 
            // rdbjapaneseyen
            // 
            this.rdbjapaneseyen.AutoSize = true;
            this.rdbjapaneseyen.Location = new System.Drawing.Point(766, 362);
            this.rdbjapaneseyen.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbjapaneseyen.Name = "rdbjapaneseyen";
            this.rdbjapaneseyen.Size = new System.Drawing.Size(182, 29);
            this.rdbjapaneseyen.TabIndex = 2;
            this.rdbjapaneseyen.TabStop = true;
            this.rdbjapaneseyen.Text = "Japanese Yen";
            this.rdbjapaneseyen.UseVisualStyleBackColor = true;
            // 
            // rdbusdollar
            // 
            this.rdbusdollar.AutoSize = true;
            this.rdbusdollar.Location = new System.Drawing.Point(766, 429);
            this.rdbusdollar.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.rdbusdollar.Name = "rdbusdollar";
            this.rdbusdollar.Size = new System.Drawing.Size(134, 29);
            this.rdbusdollar.TabIndex = 3;
            this.rdbusdollar.TabStop = true;
            this.rdbusdollar.Text = "US Dollar";
            this.rdbusdollar.UseVisualStyleBackColor = true;
            // 
            // txtamount
            // 
            this.txtamount.Location = new System.Drawing.Point(766, 223);
            this.txtamount.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtamount.Name = "txtamount";
            this.txtamount.Size = new System.Drawing.Size(196, 31);
            this.txtamount.TabIndex = 4;
            // 
            // txtconvertedamount
            // 
            this.txtconvertedamount.Location = new System.Drawing.Point(766, 594);
            this.txtconvertedamount.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtconvertedamount.Name = "txtconvertedamount";
            this.txtconvertedamount.Size = new System.Drawing.Size(196, 31);
            this.txtconvertedamount.TabIndex = 5;
            // 
            // lblselectcurrency
            // 
            this.lblselectcurrency.AutoSize = true;
            this.lblselectcurrency.Location = new System.Drawing.Point(370, 400);
            this.lblselectcurrency.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblselectcurrency.Name = "lblselectcurrency";
            this.lblselectcurrency.Size = new System.Drawing.Size(165, 25);
            this.lblselectcurrency.TabIndex = 6;
            this.lblselectcurrency.Text = "Select Currency";
            // 
            // lblamount
            // 
            this.lblamount.AutoSize = true;
            this.lblamount.Location = new System.Drawing.Point(376, 223);
            this.lblamount.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblamount.Name = "lblamount";
            this.lblamount.Size = new System.Drawing.Size(85, 25);
            this.lblamount.TabIndex = 7;
            this.lblamount.Text = "Amount";
            // 
            // lblvalue
            // 
            this.lblvalue.AutoSize = true;
            this.lblvalue.Location = new System.Drawing.Point(376, 606);
            this.lblvalue.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblvalue.Name = "lblvalue";
            this.lblvalue.Size = new System.Drawing.Size(67, 25);
            this.lblvalue.TabIndex = 8;
            this.lblvalue.Text = "Value";
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(1156, 467);
            this.btnclear.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(150, 44);
            this.btnclear.TabIndex = 9;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // rdb_MYR
            // 
            this.rdb_MYR.AutoSize = true;
            this.rdb_MYR.Location = new System.Drawing.Point(766, 482);
            this.rdb_MYR.Margin = new System.Windows.Forms.Padding(6);
            this.rdb_MYR.Name = "rdb_MYR";
            this.rdb_MYR.Size = new System.Drawing.Size(214, 29);
            this.rdb_MYR.TabIndex = 10;
            this.rdb_MYR.TabStop = true;
            this.rdb_MYR.Text = "Malaysian Ringgit";
            this.rdb_MYR.UseVisualStyleBackColor = true;
//          
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 865);
            this.Controls.Add(this.rdb_MYR);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.lblvalue);
            this.Controls.Add(this.lblamount);
            this.Controls.Add(this.lblselectcurrency);
            this.Controls.Add(this.txtconvertedamount);
            this.Controls.Add(this.txtamount);
            this.Controls.Add(this.rdbusdollar);
            this.Controls.Add(this.rdbjapaneseyen);
            this.Controls.Add(this.btnconvert);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnconvert;
        private System.Windows.Forms.RadioButton rdbjapaneseyen;
        private System.Windows.Forms.RadioButton rdbusdollar;
        private System.Windows.Forms.TextBox txtamount;
        private System.Windows.Forms.TextBox txtconvertedamount;
        private System.Windows.Forms.Label lblselectcurrency;
        private System.Windows.Forms.Label lblamount;
        private System.Windows.Forms.Label lblvalue;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.RadioButton rdb_MYR;
    }
}

